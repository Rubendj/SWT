package views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import config.Conexion;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Login {

	private JFrame frmAccesoADoatos;
	private JTextField txtUsuario;
	private JTextField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frmAccesoADoatos.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAccesoADoatos = new JFrame();
		frmAccesoADoatos.getContentPane().setBackground(Color.PINK);
		frmAccesoADoatos.getContentPane().setLayout(null);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNombre.setBounds(62, 70, 79, 14);
		frmAccesoADoatos.getContentPane().add(lblNombre);
		
		JLabel lblContrasea = new JLabel("Contrase\u00F1a");
		lblContrasea.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblContrasea.setBounds(62, 111, 79, 14);
		frmAccesoADoatos.getContentPane().add(lblContrasea);
		
		txtUsuario = new JTextField();
		txtUsuario.setBounds(205, 69, 159, 20);
		frmAccesoADoatos.getContentPane().add(txtUsuario);
		txtUsuario.setColumns(10);
		
		txtPassword = new JTextField();
		txtPassword.setBounds(205, 105, 159, 20);
		frmAccesoADoatos.getContentPane().add(txtPassword);
		txtPassword.setColumns(10);
		
		JButton btnLogin = new JButton("Acceder");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				acceder();
			}
		});
		btnLogin.setBounds(121, 169, 159, 31);
		frmAccesoADoatos.getContentPane().add(btnLogin);
		frmAccesoADoatos.setTitle("Acceso a datos");
		frmAccesoADoatos.setBounds(100, 100, 450, 300);
		frmAccesoADoatos.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	private void acceder() {
		Connection conn = new Conexion().conectar();
		
		try {
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM user WHERE username = ? and password = ?");
			ps.setString(1, txtUsuario.getText());
			ps.setString(2, txtPassword.getText());
			
			ResultSet rs = ps.executeQuery(); // ejecutar la select
			
			// System.out.println(rs.next());
			
			if(rs.next()) {
				Principal p = new Principal();
				p.frame.setVisible(true);
				} else {
				JOptionPane.showMessageDialog(null, "Error de login");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
} // cierra la clase
